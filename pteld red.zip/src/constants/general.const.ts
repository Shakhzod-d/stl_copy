export const PAGE_LIMIT = 10;
export const SELECT_PAGE_LIMIT = 1000;
