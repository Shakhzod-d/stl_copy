export interface IOnlyCompanyForm {
    name: string;
    home_terminal_timezone: string | null;
    phone: string;
    dot_number: string;
    address: string;
    home_terminal_address: string;
    id?: number;
}
