import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import MainLayout from "@/layouts/MainLayout";
import LogActions from "./LogActions";
import LogForm from "./LogForm";
import LogGraph from "./LogGraph";
import LogHead from "./LogHead";
import TripPlanner from "./TripPlanner";
import useApi from "@/hooks/useApi";
import { useQueryParam, withDefault, NumberParam } from "use-query-params";
import { IDriverData } from "@/types/driver.type";
import { ILog, ILogData } from "@/types/log.type";
import useMomentZone from "@/hooks/useMomentZone";
import TruckLoader from "@/components/loaders/TruckLoader";
import { NOT_DRAW_STATUSES, POINT_STATUSES } from "./constants";
import LogTable from "./LogTable";
import LogCorrection from "./LogCorrection";
import { useGraphColumns } from "./LogTable/columns";
import { TItemStatus } from "@/types";
import {
  addNewLog,
  correctLogsTime,
  cropOneDayLogs,
  fixLogsStatus,
  getNewLog,
  getTodaysInitialTime,
  mapDataBeforeSend,
} from "./correction_algorithms";
import { IInsertInfoLogFormData } from "./LogActions/components/InsertInfoLog";
import { v4 as uuidV4 } from "uuid";
import useApiMutation from "@/hooks/useApiMutation";
import { useEditDailyLog } from "@/api/mutations/logsMutation";
import { getLocalStorage, mapDriverLogs } from "@/utils";
import { notification } from "antd";
import useAppSelector from "@/hooks/useAppSelector";

const LogsInner: React.FC = () => {
  const momentZone = useMomentZone();

  const { userData } = useAppSelector(({ auth }) => auth);

  const { id } = useParams<{ id: string }>();
  const [time, setTime] = useQueryParam(
    "time",
    withDefault(NumberParam, momentZone().valueOf())
  );

  const { data, refetch, isFetching } = useApi<ILogData>(
    "/logs",
    { date: momentZone(time).unix(), driverId: id },
    { suspense: true }
  );
  const { data: driverData } = useApi<IDriverData>(
    `driver/${id}`,
    {},
    { suspense: true }
  );

  const { mutate, status: transferStatus } = useApiMutation<ILogData>("logs");

  const { editLogsMutation } = useEditDailyLog((props) => {
    setIsLogsEdited(false);
    setLogStatus("table");
    setInitialLogs(logs);
    setRangeVal(0);
    refetch();
  });

  const [logStatus, setLogStatus] = useState<"correction" | "table">("table");
  const [currentLog, setCurrentLog] = useState<ILog | null>(null);
  const [isVisibleInsertInfoLog, setIsVisibleInsertInfoLog] = useState(false);
  const [infoLogFormData, setInfoLogFormData] = useState<ILog | undefined>();
  const [isLogsEdited, setIsLogsEdited] = useState(false);
  const [rangeVal, setRangeVal] = useState<any>();

  const [logs, setLogs] = useState<ILog[]>([]);
  const [initialLogs, setInitialLogs] = useState<ILog[]>([]);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [croppedTime, setCroppedTime] = useState<[number, number]>();

  const fetchLogParams = {
    driverId: id,
    date: getTodaysInitialTime(),
  };

  const logData: ILogData | undefined = useMemo(() => {
    if (data?.data) {
      if (data.data.log?.length) {
        const mappedLogs = mapDriverLogs(data.data.log);
        const { croppedLogs, croppedTime: croppedTimeFromData } =
          cropOneDayLogs(mappedLogs, fetchLogParams.date);
        setCroppedTime(croppedTimeFromData);
      }
      return data?.data;
    }
  }, [data]);

  let totalTime = useMemo(() => {
    console.log(logs);
    const rangeLogs = logs.filter(
      (log) => !POINT_STATUSES.includes(log.status)
    );
    return rangeLogs[rangeLogs.length - 1]?.end;
  }, [logs]);

  useEffect(() => {
    if (logData?.log) {
      const startDay = momentZone(time).startOf("day").unix();
      const endDay = momentZone(time).endOf("day").unix();

      const data = logData?.log.map((el) => {
        return {
          ...el,
          start: el.start >= startDay ? el.start : startDay,
          end: el.end <= endDay ? el.end : endDay,
        };
      });
      setInitialLogs(data);
      setLogs(data);
    }
  }, [logData]);

  useEffect(() => {
    if (currentLog) {
      setIsLogsEdited(false);
      setLogStatus("correction");
    } else if (!currentLog) {
      setLogStatus("table");
    }
  }, [currentLog]);

  const onInsertInfoLogWithFormData = (formData: ILog) => {
    setInfoLogFormData(formData);
    setIsVisibleInsertInfoLog(true);
  };

  const columns = useGraphColumns(setCurrentLog, onInsertInfoLogWithFormData);

  const filterDrawStatus = (data: ILog[]) => {
    return data.filter((el) => !NOT_DRAW_STATUSES.includes(el.status));
  };

  const afterRangeChange = (val: any, currLog: ILogData) => {
    setRangeVal(val);
  };

  const onCancel = () => {
    setLogs(initialLogs);
    setRangeVal(undefined);
    setIsLogsEdited(false);
    setCurrentLog(null);
  };

  const onChangeStatus = (val: TItemStatus) => {
    if (!currentLog?.isNewLog) {
      setIsLogsEdited(true);
      const newLogs =
        logs &&
        fixLogsStatus(
          logs?.map((item) => {
            return currentLog?._id === item?._id
              ? {
                  ...item,
                  status: val,
                }
              : { ...item };
          })
        );
      setCurrentLog(
        (prev) => newLogs?.find((log) => prev?._id === log._id) || null
      );
      setLogs(newLogs);
    } else if (currentLog?.isNewLog) {
      setCurrentLog((prev) => ({
        ...prev!,
        status: val,
        rangeVal,
      }));
      setLogs([
        ...logs.filter((log) => log?._id !== currentLog?._id),
        { ...currentLog, status: val, rangeVal },
      ]);
    }
  };

  const onTimeChange = (range: [any, any]) => {
    // const startDayOclock = moment("00:00:00", "HH:mm:ss").unix();
    setRangeVal([range[0].unix() - time / 1000, range[1].unix() - time / 1000]);
    // @ts-ignore
    setCurrentLog({
      ...currentLog,
      rangeVal: [range[0].unix() - time / 1000, range[1].unix() - time / 1000],
    });
  };

  const onInsertInfoLog = (infoLog: IInsertInfoLogFormData) => {
    // @ts-ignore
    const newLog: ILog = {
      ...infoLog,
      _id: uuidV4(),
      document: "",
      // coDriverId: 0,
      // company: "",
      // driverId: fetchLogParams?.driverId,
      duration: 0,
      start: infoLog.time + time - 1,
      end: infoLog.time + time - 1,
    };
    // @ts-ignore
    setLogs(sortLogsByTime([...logs, newLog]));
  };

  const onNormalize = () => {};

  const onTransfer = (duration: number, log: ILog) => {
    // console.log({
    //      ...log,
    //      duration: duration - initialTime,
    //      // @ts-ignore
    //      start: log?.cropPoint === "start" ? croppedTime[0] : log?.start,
    //      // @ts-ignore
    //      end: log?.cropPoint === "end" ? croppedTime[1] : log?.end,
    // });
    mutate({
      ...log,
      // duration: duration - time,
      // @ts-ignore
      start: log?.cropPoint === "start" ? croppedTime[0] : log?.start,
      // @ts-ignore
      end: log?.cropPoint === "end" ? croppedTime[1] : log?.end,
    });
  };

  const onRevert = (revertLogs: ILog[]) => {
    setLogs(revertLogs);
  };

  const onSend = () => {
    if (true) {
      setRangeVal(undefined);
      setCurrentLog(null);
      const payload = {
        ...fetchLogParams,
        date: time / 1000,
        log: mapDataBeforeSend(logs, croppedTime, true, driverData!.data),
        historyLog: {
          user: userData?.firstName + " " + userData?.lastName,
          driverId: fetchLogParams.driverId,
          afterLogs: mapDataBeforeSend(logs, [0, 0], false, driverData!.data),
          beforeLogs: mapDataBeforeSend(
            initialLogs,
            [0, 0],
            false,
            driverData!.data
          ),
        },
      };
      console.log("🔥payload: ", payload);

      editLogsMutation(payload);
    } else {
      notification.error({
        message: "Change something before send!",
      });
    }
  };

  const onOk = () => {
    setIsLogsEdited(true);
    if (rangeVal) {
      if (currentLog?.isNewLog) {
        const res = addNewLog(
          logs,
          {
            ...currentLog,
            start: rangeVal[0] + time / 1000,
            end: rangeVal[1] + time / 1000,
            isNewLog: false,
            // @ts-ignore
            rangeVal: undefined,
          },
          rangeVal
        );
        const fixedStatusLogs = fixLogsStatus(res);
        // debugger;
        // setHistoryLogs([
        //      ...historyLogs,
        //      {
        //           corrector: "Rajapboyev Temurbek",
        //           _id: uuidV4(),
        //           editTime: moment(),
        //           before: logs,
        //           after: fixedStatusLogs,
        //      },
        // ]);
        setLogs(fixedStatusLogs);
      } else if (!currentLog?.isNewLog) {
        debugger;
        const getRidOfNewLog = logs.filter((log) => !log.isNewLog);
        const timeCorrectedLogs = correctLogsTime(
          getRidOfNewLog,
          // @ts-ignore
          currentLog,
          rangeVal
        );
        const fixedStatusLogs = fixLogsStatus(timeCorrectedLogs);
        // setHistoryLogs([
        //      ...historyLogs,
        //      {
        //           corrector: "Rajapboyev Temurbek",
        //           _id: uuidV4(),
        //           editTime: moment(),
        //           before: logs,
        //           after: fixedStatusLogs,
        //      },
        // ]);
        setLogs(fixedStatusLogs);
        // debugger;
      }
      setRangeVal(undefined);
    }
  };

  const onInsertDutyStatus = () => {
    let val = [
      Math.floor((totalTime - time / 1000 - 1.5 * 60 * 60) / 2),
      Math.floor((totalTime - time / 1000 + 1.5 * 60 * 60) / 2),
    ];
    console.log(logs);
    // debugger;
    const newLog: ILog = getNewLog(logs, time, val, fetchLogParams);
    setRangeVal(val);
    setLogs([...logs, newLog]);
    setCurrentLog(newLog);
  };
  const onLogClick = (log: ILog | null) => {
    /* 
    setLogs((prev) => prev.filter((log) => !log.isNewLog));*/
    setRangeVal(undefined);
    if (currentLog?.isNewLog) {
      setLogs((prev) => prev.filter((log) => !log.isNewLog));
    }
    setCurrentLog(log);
  };

  const renderInner = () =>
    ({
      table: (
        <LogTable
          data={logs}
          columns={columns}
          setHoveredId={setHoveredId}
          hoveredId={hoveredId}
          // rowSelection={rowSelection} these are must to be same
        />
      ),
      correction: (
        <LogCorrection
          currentLog={currentLog}
          onChangeStatus={onChangeStatus}
          initialTime={time}
          onCancel={onCancel}
          onTimeChange={onTimeChange}
          setLogs={setLogs}
        />
      ),
      correction_point_log: (
        <>
          <LogTable
            data={logs}
            columns={columns}
            setHoveredId={setHoveredId}
            hoveredId={hoveredId}
            // rowSelection={rowSelection} these are must to be same
          />
        </>
      ),
    }[logStatus]);

  return (
    <MainLayout>
      <div className="logs-inner page">
        {driverData && (
          <LogHead
            driverData={driverData?.data}
            initialTime={time}
            cycle={logData?.cycle}
            logs={logs}
          />
        )}
        <LogActions
          logs={logs}
          initialTime={time}
          setTime={setTime}
          currentLog={currentLog}
          setCurrentLog={setCurrentLog}
          refetch={refetch}
          logStatus={isFetching}
          driverData={driverData?.data}
          reportData={logData?.report}
          historyLogs={logData?.history}
          onInsertInfoLog={onInsertInfoLog}
          onInsertDutyStatus={onInsertDutyStatus}
          onNormalize={onNormalize}
          onTransfer={onTransfer}
          onRevert={onRevert}
          onCancel={onCancel}
          onSend={onSend}
          onOk={onOk}
          isLogsEdited={isLogsEdited}
          croppedTime={croppedTime}
          infoLogFormData={infoLogFormData}
          isVisibleInsertInfoLog={isVisibleInsertInfoLog}
          setInfoLogFormData={setInfoLogFormData}
          setIsVisibleInsertInfoLog={setIsVisibleInsertInfoLog}
          transferStatus={transferStatus}
        />
        <LogGraph
          data={filterDrawStatus(logs)}
          setHoveredId={setHoveredId}
          hoveredId={hoveredId}
          currentLog={currentLog}
          onLogClick={onLogClick}
          afterRangeChange={afterRangeChange}
          logStatus={isFetching}
          initialTime={momentZone(time).unix()}
        />

        {isFetching && <TruckLoader />}
        {renderInner()}
      </div>
      <LogForm />
      <TripPlanner />
    </MainLayout>
  );
};

export default LogsInner;
