import React from "react";
import Accordion from "@/components/elements/Accordion";

const TripPlanner: React.FC = () => {
     return (
          <></>
          // <Accordion
          //      className="mb-24"
          //      title="trip planner"
          //      content={"trip planner"}
          // />
     );
};

export default TripPlanner;
