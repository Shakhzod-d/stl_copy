import Logs from "./Logs";

export default Logs