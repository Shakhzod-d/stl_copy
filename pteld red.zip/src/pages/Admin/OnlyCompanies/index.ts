import OnlyCompanies from "./OnlyCompanies";

export default OnlyCompanies;
