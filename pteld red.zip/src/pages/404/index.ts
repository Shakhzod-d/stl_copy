import NotFound from "./404";

export default NotFound