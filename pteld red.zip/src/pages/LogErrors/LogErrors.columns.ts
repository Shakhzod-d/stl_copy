export const useLogErrors = (): any => {
  return [];
};
