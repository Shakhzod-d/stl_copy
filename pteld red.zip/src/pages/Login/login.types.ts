import { IUserData } from "@/types/user.type";

export interface ILoginData {
    data: IUserData;
}
