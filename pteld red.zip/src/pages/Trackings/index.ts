import Trackings from "./Trackings";

export default Trackings