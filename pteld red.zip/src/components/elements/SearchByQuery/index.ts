import SearchByQuery from "./SearchByQuery";

export default SearchByQuery