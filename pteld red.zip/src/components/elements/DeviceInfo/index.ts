import DeviceInfo from "./DeviceInfo";

export default DeviceInfo