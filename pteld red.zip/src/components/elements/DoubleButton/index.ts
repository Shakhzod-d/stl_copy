import DoubleButton from "./DoubleButton";

export default DoubleButton